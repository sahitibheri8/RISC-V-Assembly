.section .text
.align 12
.globl main

main:
    
    li t0, -1
    csrw pmpaddr0, t0
    li t0, 0x1F        
    csrw pmpcfg0, t0

    
    li t0, 0x00001800
    csrs mstatus, t0

    
    la t0, supervisor_code
    csrw mepc, t0

    
    mret

supervisor_code:
    
    la t0, pt3
    li t1, 24576
    add t2, t0, t1
clear_pt:
    sd zero, 0(t0)
    addi t0, t0, 8
    blt t0, t2, clear_pt

    
    la t0, pt3
    la t1, pt2          
    srli t1, t1, 2     
    li t2, 0x1          
    or t1, t1, t2
    sd t1, 0(t0)        

    
    la t0, pt2

    
    la t1, pt1_user
    srli t1, t1, 2
    li t2, 0x1
    or t1, t1, t2
    sd t1, 0(t0)

    
    la t1, pt1_ident
    srli t1, t1, 2
    li t2, 0x1
    or t1, t1, t2
    li t3, 16
    add t4, t0, t3
    sd t1, 0(t4)

    la t0, pt1_user
    la t1, pt0_user
    srli t1, t1, 2
    li t2, 0x1
    or t1, t1, t2
    sd t1, 0(t0)

    
    la t0, pt1_ident
    la t1, pt0_ident
    srli t1, t1, 2
    li t2, 0x1
    or t1, t1, t2
    li t3, 832
    add t4, t0, t3
    sd t1, 0(t4)

    
    la t0, pt0_user

    la t1, user_code
    srli t1, t1, 2
    li t2, 0xDB         
    or t1, t1, t2
    sd t1, 0(t0)        

    
    la t1, user_data
    srli t1, t1, 2
    li t2, 0xD7         
    or t1, t1, t2
    sd t1, 8(t0)        

   
    la t0, pt0_ident
    li t1, 0x8D000000
    srli t1, t1, 2
    li t2, 0xCF        
    li t3, 16          
    li t4, 0
map_ident_loop:
    or t5, t1, t2
    sd t5, 0(t0)
    addi t0, t0, 8
    li t6, 0x400      
    add t1, t1, t6
    addi t4, t4, 1
    blt t4, t3, map_ident_loop

   
    la t0, pt3
    srli t0, t0, 12     
    li t1, 9            
    slli t1, t1, 60    
    or t0, t0, t1       
    csrw satp, t0
    sfence.vma         

   
    li t0, 0x100           
	csrc sstatus, t0       
    
    
    li t0, 0x00000000
    csrw sepc, t0

    sret

.section .user_text, "ax"
.globl user_code
user_code:
    
    li t0, 0x00001000
    lw t1, 0(t0)

user_end:
    j user_end

.section .data
.align 12
.globl user_data
user_data:
    .word 0xDEADBEEF