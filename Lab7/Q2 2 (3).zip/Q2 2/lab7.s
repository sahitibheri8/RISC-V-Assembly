.section .text
.global _start

_start:
    la sp , _stack_top

    la t0 , mtrap_handler
    csrw mtvec , t0

    li t0 , ~(3 << 11)
    csrr t1 , mstatus
    and t1 , t1 , t0
    csrw mstatus , t1

    la t0 , ucode
    csrw mepc , t0

    mret

ucode:
    .word 0x00000000
    ebreak
    la t0, _stack_low
    addi t0, t0, 1
    lw t0, 0(t0)
    li t0, 0x0
    lw t1, 0(t0)
    ecall

.section .text
.align 4
mtrap_handler:

    addi sp , sp , -64
    sw t0 , 8(sp)
    sw t1 , 16(sp)
    sw t2 , 24(sp)
    sw t3 , 32(sp)
    sw t4 , 40(sp)
    sw t5 , 48(sp)
    sw t6 , 56(sp)

    csrr t0 , mcause
    li t1 , 3
    beq t0 , t1 , handle_breakpoint
    li t1 , 2
    beq t0 , t1 , handle_illegalinstr
    li t1 , 8
    beq t0 , t1 , handle_ecall
    li t1 , 4
    beq t0 , t1 , handle_loadaddrmissalign
    li t1 , 5
    beq t0 , t1 , handle_loadaccessfault

handle_ecall:
    csrr t0 , mepc
    addi t0 , t0 , 4
    csrw mepc , t0

    li a0 , 0xFEED

    j exit

handle_breakpoint:
    csrr t0 , mepc
    addi t0 , t0 , 4
    csrw mepc , t0

    li a0 , 0xBEEF

    j exit

handle_illegalinstr:
    csrr s9 , mtval

    csrr t0 , mepc
    addi t0 , t0 , 4
    csrw mepc , t0

    j exit

handle_loadaddrmissalign:
    csrr s10 , mtval

    csrr t0 , mepc
    addi t0 , t0 , 4
    csrw mepc , t0

    j exit

handle_loadaccessfault:
    csrr s11 , mtval

    csrr t0 , mepc
    addi t0 , t0 , 4
    csrw mepc , t0

    j exit

exit:
    lw t0 , 8(sp)
    lw t1 , 16(sp)
    lw t2 , 24(sp)
    lw t3 , 32(sp)
    lw t4 , 40(sp)
    lw t5 , 48(sp)
    lw t6 , 56(sp)

    addi sp , sp , 64

    mret

.section .bss
.align 16
_stack_low:
.space 4096
_stack_top:







