#include <stdio.h>
extern int decrypt(char* cipher_text, char substitution[] , char substitution2[]); // forward declaration with arguments
extern char ans[];                             // forward declaration
char *cipher_text = "kocvuzwyliuwslylkmlzvnclwylfbzlbok\0";
char substitution[] = {
    'w', 't', 'z', 'f', 'v',
    'i', 's', 'h', 'l', 'g',
    'a', 'y', 'e', 'r', 'b',
    'c', 'p', 'u', 'k', 'm',
    'o', 'd', 'x', 'n', 'j',
    'q'};

char substitution2[] = {
    'a', 'b', 'c', 'd', 'e',
    'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o',
    'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y',
    'z'};
int main()
{
    decrypt(cipher_text , substitution , substitution2);
    // call the decryption function from assembly
    printf("recovered␣plain␣text:␣%s\n", ans);
}