.data

.global ans 
ans: .space 40

.section .text
.global decrypt

decrypt:

    la t1 , ans

    li t0 , 0  #i

    loop:

    add t6 , a0 , t0
    lb t3 , 0(t6)
    beqz t3 , end

    li t4 , 0 #j

        innerloop:
            add t2 , a1 , t4
            lb t6 , 0(t2)

            beq t6 , t3 , found

            addi t4 , t4 , 1
            j innerloop

    found:

        add t2 , a2 , t4
        lb t6 , 0(t2)

        sb t6 , 0(t1)
        addi t1 , t1 , 1

        addi t0 , t0 , 1
        j loop

    end:

        sb zero , 0(t1)
        la t1 , ans
        mv a0 , t1
        ret
