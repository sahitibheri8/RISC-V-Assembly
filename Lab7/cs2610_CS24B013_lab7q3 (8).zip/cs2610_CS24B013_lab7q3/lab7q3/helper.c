typedef unsigned long long uint64_t;

volatile int count_var = 0;
volatile int flag_var = 0;
volatile int fib_array[10] = {0};

int current_process = 0;
uint64_t process_table[4] = {0};

uint64_t user_stacks[4][128];

void ucode_counter(void)
{
    while (1)
    {
        count_var++;
        for (volatile int i = 0; i < 10000; i++)
            ;
    }
}

void ucode_fib(void)
{
    fib_array[0] = 0;
    fib_array[1] = 1;
    while (1)
    {
        for (int i = 2; i < 10; i++)
        {
            fib_array[i] = fib_array[i - 1] + fib_array[i - 2];
        }
    }
}

void ucode_checker(void)
{
    while (1)
    {
        flag_var = !flag_var;
        for (volatile int i = 0; i < 10000; i++)
            ;
    }
}

void ucode_idle(void)
{
    while (1)
    {
    }
}

struct init_ctx
{
    uint64_t sp;
    uint64_t mepc;
};

struct init_ctx setup_processes(void)
{

    process_table[0] = (uint64_t)&user_stacks[0][128];

    uint64_t sp1 = (uint64_t)&user_stacks[1][128] - 256;
    *(uint64_t *)sp1 = (uint64_t)ucode_fib;
    process_table[1] = sp1;

    uint64_t sp2 = (uint64_t)&user_stacks[2][128] - 256;
    *(uint64_t *)sp2 = (uint64_t)ucode_checker;
    process_table[2] = sp2;

    uint64_t sp3 = (uint64_t)&user_stacks[3][128] - 256;
    *(uint64_t *)sp3 = (uint64_t)ucode_idle;
    process_table[3] = sp3;

    struct init_ctx ctx;
    ctx.sp = process_table[0];
    ctx.mepc = (uint64_t)ucode_counter;

    return ctx;
}

uint64_t switch_processes(uint64_t current_sp)
{
    process_table[current_process] = current_sp;

    current_process = (current_process + 1) % 4;

    return process_table[current_process];
}