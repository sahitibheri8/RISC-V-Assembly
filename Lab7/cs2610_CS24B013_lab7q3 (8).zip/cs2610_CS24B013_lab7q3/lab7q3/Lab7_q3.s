.global _start
.global mtrap_handler
.global increment_timer

# Define the memory-mapped address for mtimecmp
.equ MTIMECMP_ADDR, 0x2004000

.section .text


_start:
    # Initialize the machine stack so we have a valid sp before the first switch
    la sp, _machine_stack_top

    # Call setup_processes (C function). 
    # It returns a struct with {sp, mepc}, which RISC-V places in a0 and a1.
    call setup_processes

    # Use the return values to set the first process's sp and mepc
    mv sp, a0
    csrw mepc, a1

    # Set mtvec to point to our trap handler
    la t0, mtrap_handler
    csrw mtvec, t0

    
    li t0, MTIMECMP_ADDR
    li t1, 0x100
    sd t1, 0(t0)

    # Enable machine timer interrupts (MTIE is bit 7 in mie)
    li t0, 0x80
    csrs mie, t0

    # Enable global interrupts (MIE is bit 3 in mstatus)
    li t0, 0x8
    csrs mstatus, t0

    # Jump into the first user process using mepc
    mret


increment_timer:
    li t0, MTIMECMP_ADDR
    ld t1, 0(t0)        # Load current mtimecmp (64-bit)
    li t2, 0x100        # Increment value by 0x100
    add t1, t1, t2
    sd t1, 0(t0)        # Store updated value back
    ret


.align 4
mtrap_handler:
    # Make room on the current process's stack for 31 registers + mepc (32 * 8 = 256 bytes)
    addi sp, sp, -256

    # Save mepc
    csrr t0, mepc
    sd t0, 0(sp)

    # Save all general-purpose registers (skip x0 which is hardwired to 0, and x2 which is sp)
    sd x1, 8(sp)
    sd x3, 16(sp)
    sd x4, 24(sp)
    sd x5, 32(sp)
    sd x6, 40(sp)
    sd x7, 48(sp)
    sd x8, 56(sp)
    sd x9, 64(sp)
    sd x10, 72(sp)
    sd x11, 80(sp)
    sd x12, 88(sp)
    sd x13, 96(sp)
    sd x14, 104(sp)
    sd x15, 112(sp)
    sd x16, 120(sp)
    sd x17, 128(sp)
    sd x18, 136(sp)
    sd x19, 144(sp)
    sd x20, 152(sp)
    sd x21, 160(sp)
    sd x22, 168(sp)
    sd x23, 176(sp)
    sd x24, 184(sp)
    sd x25, 192(sp)
    sd x26, 200(sp)
    sd x27, 208(sp)
    sd x28, 216(sp)
    sd x29, 224(sp)
    sd x30, 232(sp)
    sd x31, 240(sp)

    # Prepare for the next interrupt
    call increment_timer

    # Call switch_processes. Pass current sp via a0.
    mv a0, sp
    call switch_processes
    
    # switch_processes returns the new process's sp in a0. Update our sp.
    mv sp, a0

    # Restore the new process's mepc
    ld t0, 0(sp)
    csrw mepc, t0

    # Restore the new process's general-purpose registers
    ld x1, 8(sp)
    ld x3, 16(sp)
    ld x4, 24(sp)
    ld x5, 32(sp)
    ld x6, 40(sp)
    ld x7, 48(sp)
    ld x8, 56(sp)
    ld x9, 64(sp)
    ld x10, 72(sp)
    ld x11, 80(sp)
    ld x12, 88(sp)
    ld x13, 96(sp)
    ld x14, 104(sp)
    ld x15, 112(sp)
    ld x16, 120(sp)
    ld x17, 128(sp)
    ld x18, 136(sp)
    ld x19, 144(sp)
    ld x20, 152(sp)
    ld x21, 160(sp)
    ld x22, 168(sp)
    ld x23, 176(sp)
    ld x24, 184(sp)
    ld x25, 192(sp)
    ld x26, 200(sp)
    ld x27, 208(sp)
    ld x28, 216(sp)
    ld x29, 224(sp)
    ld x30, 232(sp)
    ld x31, 240(sp)

    # Deallocate the space used for context saving
    addi sp, sp, 256

    # Return to user code
    mret


.section .bss
.align 4
.global _machine_stack
_machine_stack:
    .space 1024       # 1KB temporary stack for kernel boot
_machine_stack_top: