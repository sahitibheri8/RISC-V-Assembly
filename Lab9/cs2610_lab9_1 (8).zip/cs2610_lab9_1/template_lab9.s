
.section .text
.global main



main:
    # Prepare jump to super mode
    li t1, 1
    slli t1, t1, 11   #mpp_mask
    csrs mstatus, t1
    
    la t4, supervisor       #load address of user-space code
    csrrw zero, mepc, t4    #set mepc to user code
    
    la t5, page_fault_handler
    csrw mtvec, t5
   
    mret

supervisor:
################## Setting up page tables ##############
    # Set value in PTE2 (Initial Mapping)
    li a0,0x81000000
    li a1, 0x82000
    slli a1, a1, 0xa
    ori a1, a1, 0x01 # | - | - | - |V
    sd a1, 16(a0)

    # To set V.A 0x0 -> P.A 0x0
    li a1, 0x82001
    slli a1, a1, 0xa
    ori a1, a1, 0x01 # | - | - | - |V
    sd a1, 0(a0)

    # Set value in PTE1 (Initial Mapping)
    li a0,0x82000000
    li a1, 0x83000
    slli a1, a1, 0xa
    ori a1, a1, 0x01 # | - | - | - |V
    sd a1, 0(a0)

    # Set Frame number in PTE0 (Initial Mapping)
    li a0,0x83000000
    li a1, 0x80000
    slli a1, a1, 0xa
    ori a1, a1, 0xef # D | A | G | - | X | W | R |V
    sd a1, 0(a0)

    li a1, 0x80001
    slli a1, a1, 0xa
    ori a1, a1, 0xef # D | A | G | - | X | W | R |V
    sd a1, 8(a0)

    # Set value in PTE1 (Code Mapping)
    li a0,0x82001000
    li a1, 0x83001
    slli a1, a1, 0xa
    ori a1, a1, 0x01 # | - | - | - |V
    sd a1, 0(a0)

    # Set value in PTE0 (Code Mapping)
    li a0,0x83001000
    li a1, 0x80001
    slli a1, a1, 0xa
    ori a1, a1, 0xfb # D | A | G | U | X | - | R |V
    sd a1, 0(a0)

    # Data Mapping
    li a1, 0x80002
    slli a1, a1, 0xa
    ori a1, a1, 0xf7 # D | A | G | U | - | W | R |V
    sd a1, 8(a0)
    

####################################################################

    # Prepare jump to user mode
    li t1, 0
    slli t1, t1, 8   #spp_mask
    csrs sstatus, t1

    # Configure satp
    la t1, satp_config 
    ld t2, 0(t1)
    sfence.vma zero, zero
    csrrw zero, satp, t2
    sfence.vma zero, zero

    li t4, 0       # load VA address of user-space code
    csrrw zero, sepc, t4    # set sepc to user code
    
    sret



###################################################################
##################### ADD CODE ONLY HERE  #########################
###################################################################
.align 4
page_fault_handler:

    la t0, backup_area
    sd t1, 8(t0)
    sd t2, 16(t0)
    sd t3, 24(t0)
    sd t4, 32(t0)
    sd t5, 40(t0)
    sd t6, 48(t0)

    csrr t1, mcause
    li t2, 12
    beq t1, t2, inst_fault
    li t2, 13
    beq t1, t2, data_fault
    li t2, 15
    beq t1, t2, data_fault
    j exit              

inst_fault:


    li t6, 1               
    j process_fault

data_fault:


    li t6, 0   
            

process_fault:



    csrr t1, mtval         

    srli t2, t1, 21
    li t3, 0x1FF
    and t2, t2, t3

    li t3, 0x82001000
    slli t4, t2, 3
    add t3, t3, t4

    ld t4, 0(t3)
    andi t5, t4, 1
    bnez t5, l1_valid

    la t5, nextfree_l0pt
    ld t4, 0(t5)       
    li t2, 0x1000    
    add t2, t4, t2
    sd t2, 0(t5)           

    mv t2, t4
    li t5, 0x1000
    add t5, t2, t5


zero_l0:


    sd zero, 0(t2)
    addi t2, t2, 8
    bltu t2, t5, zero_l0

    srli t2, t4, 12
    slli t2, t2, 10
    ori t2, t2, 1          
    sd t2, 0(t3)           

    j get_l0

l1_valid:


    srli t4, t4, 10
    slli t4, t4, 12

get_l0:


    srli t2, t1, 12
    li t3, 0x1FF
    and t2, t2, t3

    slli t2, t2, 3
    add t4, t4, t2         

    bnez t6, handle_inst

handle_data:


    li t2, 0x80002
    slli t2, t2, 10
    ori t2, t2, 0xF7       
    sd t2, 0(t4)           
    j exit

handle_inst:



    la t5, nextfree_page
    ld t2, 0(t5)   
    li t3, 0x1000        
    add t3, t2, t3
    sd t3, 0(t5)           

    srli t3, t2, 12
    slli t3, t3, 10
    ori t3, t3, 0xFB      
    sd t3, 0(t4)           

    li t3, 0x80001000
    li t4, 0x1000
    add t4, t3, t4        
    
copy_page:

    ld t5, 0(t3)
    sd t5, 0(t2)
    addi t3, t3, 8
    addi t2, t2, 8
    bltu t3, t4, copy_page

exit:

    sfence.vma zero, zero

    la t0, backup_area
    ld t1, 8(t0)
    ld t2, 16(t0)
    ld t3, 24(t0)
    ld t4, 32(t0)
    ld t5, 40(t0)
    ld t6, 48(t0)

    mret

.data
.align 3
backup_area:   .space 64
nextfree_l0pt: .dword 0x83002000
nextfree_page: .dword 0x80003000

.text
###################################################################
###################################################################



.align 12
user_code:
    la t1,var_count
    lw t2, 0(t1)
    addi t2, t2, 1
    sw t2, 0(t1)

    la t5, code_jump_position
    lw t3, 0(t5)
    li t4, 0x2000
    add t3, t3, t4
    sw t3, 0(t5)
    
    jalr x0, t3


.data
.align 12
var_count:  .word  0
code_jump_position: .word 0x0000


.align 8
# Value to set in satp
satp_config: .dword 0x8000000000081000
