.section .text
.global main

main:
    la t0, mtrap_handler
    csrw mtvec, t0

    la t0, strap_handler
    csrw stvec, t0

    li t0, (1 << 8)
    csrw medeleg, t0

    la t0, ucode
    csrw mepc, t0

    csrr t1, mstatus
    li t2, ~(3 << 11)
    and t1, t1, t2
    csrw mstatus, t1

    mret

.align 4
mtrap_handler:
	csrr t6, mstatus
    mul a1, a1, a2
    li a0, 0
    la t0, strap_handler
    csrw mepc, t0
    mret

scode:
    la t0, ucode1
    csrw sepc, t0
    sret

.align 4
strap_handler:
	csrr t6 , sstatus
    csrr t0, sepc
    addi t0, t0, 4
    csrw sepc, t0
    beq a0, x0, go_user
    ecall

go_user:
    j scode

ucode:
    li a1, 5
    li a2, 3
    li a0, 0
    ecall

ucode1:
    add a1, a1, a2
    li a0, 1
    ecall