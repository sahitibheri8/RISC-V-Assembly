.data
    arr : .word 1 , 56 , 14
    n : .word 3
    x : .word 2
    temp : .word 0

.text
.global main

main:
    la t0 , arr
    lw t1 , n
    lw t2 , x
    li t3 , 0 #i
    li t4 , 0 #j
    la a3 , temp

loop:
    beq t3 , t2 , final
    li t4 , 0

inner_loop:
    sub a2 , t2 , t3

    beq a2 , t4 , increment
    slli t5 , t4 , 2
    add t5 , t5 , t0
    lw a2 , 0(t5)   #arr[j]

    addi t6 , t4 , 1
    slli t6 , t6 , 2
    add t6 , t6 , t0
    lw a0 , 0(t6)   #arr[j+1]

    bgt a2 , a0 , change
    addi t4 , t4 , 1
    j inner_loop

change:
    addi a4 , a2 , 0  #temp
    
    sw a0 , 0(t5)
    sw a4 , 0(t6)
    addi t4 , t4 , 1
    j inner_loop

increment:
    addi t3 , t3 , 1
    j loop

final:
    li a7 , 93
    ecall

