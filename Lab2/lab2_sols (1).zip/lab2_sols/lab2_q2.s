.data
    mat1 : .word 1 ,2 , 3 , 4 , 5 , 6 , 7 , 8 , 9
    mat2 : .word 9 , 8 , 7 , 6 , 5 , 4 ,3 , 2 , 1
    n : .word 3
    sum : .word 0
    result : .word 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0

.text
.global main

main:
    la t0 , mat1
    la t1 , mat2
    lw t2 , n
    li t3 , 0  #i
    li t4 , 0  #j
    la a0 , sum
    li a1 , 0  #sum
    li t5 , 0  #k
    la a5 , result

loop:
    beq t3 , t2 , final
    li t4 , 0

inner_loop:
    beq t4 , t2 , increment
    li t5 , 0
    li a1 , 0

    mul t6 , t3 , t2
    add t6 , t6 , t5
    slli t6 , t6 , 2
    add t6 , t6 , t0
    lw a2 , 0(t6)   #mat1[i][k]

    mul t6 , t5 , t2
    add t6 , t6 , t4
        slli t6 , t6 , 2
    add t6 , t6 , t1
    lw a3 , 0(t6)   #mat2[k][j]

    mul a4 , a2 , a3
    add a1 , a1 , a4

    addi t5 , t5 , 1  #k++

    mul t6 , t3 , t2
    add t6 , t6 , t5
        slli t6 , t6 , 2
    add t6 , t6 , t0
    lw a2 , 0(t6)

    mul t6 , t5 , t2
    add t6 , t6 , t4
        slli t6 , t6 , 2
    add t6 , t6 , t1
    lw a3 , 0(t6)

    mul a4 , a2 , a3
    add a1 , a1 , a4

    addi t5 , t5 , 1  #k++

    mul t6 , t3 , t2
    add t6 , t6 , t5
        slli t6 , t6 , 2
    add t6 , t6 , t0
    lw a2 , 0(t6)

    mul t6 , t5 , t2
    add t6 , t6 , t4
        slli t6 , t6 , 2
    add t6 , t6 , t1
    lw a3 , 0(t6)

    mul a4 , a2 , a3
    add a1 , a1 , a4

    mul t6 , t3 , t2
    add t6 , t6 , t4
        slli t6 , t6 , 2
    add t6 , t6 , a5
    sw a1 , 0(t6)

    addi t4 , t4 , 1
    j inner_loop

increment:
    addi t3 , t3 , 1
    j loop

final:
    li a7 , 93
    ecall



