.data
    array : .word 10 , 10 , 10 , 10 , 10
    size : .word 5

.text
.global main

main:
    la t0 , array
    lw t1 , size
    li t2 , 0

loop:
    beq t2 , t1 , end_loop
    andi t3 , t2 , 1
    slli t6 , t2 , 2
    add t6 , t6 , t0
    lw t4 , 0(t6)
    beq t3 , zero , even_loop
    addi t4 , t4 , -1
    sw t4 , 0(t6)
    addi t2 , t2 , 1
    j loop

even_loop:
    addi t4 , t4 , 1
    sw t4 , 0(t6)
    addi t2 , t2 , 1
    j loop

end_loop:
    li a7 , 93
    ecall


