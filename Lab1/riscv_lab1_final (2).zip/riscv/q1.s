.data
    num1 : .word 1
    num2 : .word 2
    add_res : .word 0
    sub_res : .word 0
    and_res : .word 0
    or_res : .word 0
    xor_res : .word 0

.text
.global main

main:
    la t0 , num1
    lw t1 , num1
    la t2 , num2
    lw t3 , num2

loop:
    
    add t4 , t1 , t3
    la t0 , add_res
    sw t4 , 0(t0)

    sub t4 , t1 , t3
    la t0 , sub_res
    sw t4 , 0(t0)

    and t4 , t1 , t3
    la t0 , and_res
    sw t4 , 0(t0)

    or t4 , t1 , t3
    la t0 , or_res
    sw t4 , 0(t0)

    xor t5 , t1 , -1
    xor t4 , t5 , t3
    la t0 , xor_res
    sw t4 , 0(t0)




end_loop:
    li a7 , 93
    ecall
