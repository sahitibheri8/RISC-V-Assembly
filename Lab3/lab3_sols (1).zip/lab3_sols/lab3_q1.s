.data
    n : .dword 5678

.text
.global main

main:
    ld a0 , n
    jal ra , sum_of_digits

    li a7 , 93
    ecall

sum_of_digits:
    addi sp , sp , -24
    sd ra , 8(sp)
    sd a0 , 0(sp)

    li t6 , 10
    blt a0 , t6 , base_case

    ld t5 , 0(sp)
    li t4 , 10
    rem t5 , t5 , t4
    sd t5 , 16(sp)  #n mod 10

    ld t3 , 0(sp)
    div t3 , t3 , t4
    mv a0 , t3

    jal ra , sum_of_digits

    ld t2 , 16(sp)
    add a0 , a0 , t2
    j final

base_case:
    # do nothing

final:
    ld ra , 8(sp)
    addi sp , sp , 24
    ret