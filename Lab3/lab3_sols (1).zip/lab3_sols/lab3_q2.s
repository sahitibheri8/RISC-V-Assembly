.data
    n : .dword 2
    buffer: .space 21
    newline : .asciz "\n"

.text
.global main

main:
    ld a0 , n
    ld a1 , n
    li a2 , 0
    li t6 , '('
    li t5 , ')'

    jal ra , paran
    li a7 , 93
    ecall

paran:

    addi sp , sp , -32
    sd ra , 24(sp)
    sd a2 , 16(sp)  #ind
    sd a1 , 8(sp)   #close
    sd a0 , 0(sp)   #open

    bgt a0 , zero , first_recur
    bgt a1 , a0 , second_recur

    la t0, buffer
    add t0, t0, a2 # a2 holds idx
    sb zero, 0(t0)

    li a0, 1 # file descriptor (stdout)
    la a1, buffer # address of string
    mv a2, a2 # length of string (idx)
    li a7, 64 # syscall number for write
    ecall 

    li a0, 1
    la a1, newline
    li a2, 1
    li a7, 64
    ecall

    ld ra , 24(sp)
    addi sp , sp , 32
    ret


first_recur:

    ld t0 , 0(sp)   #open
    ld t1 , 8(sp)   #close
    ld t2 , 16(sp)  #ind

    la t4, buffer
    add t4, t4, t2 # a2 holds idx
    sb t6 , 0(t4)

    addi t0 , t0 , -1
    addi t2 , t2 , 1

    mv a0 , t0
    mv a1 , t1
    mv a2 , t2

    jal ra , paran

    ld a0 , 0(sp)   #open
    ld a1 , 8(sp)   #close
    ld a2 , 16(sp)  #ind
    ld ra , 24(sp)
    ble a1 , a0 , exit_second_recur

second_recur:

    ld t0 , 0(sp)   #open
    ld t1 , 8(sp)   #close
    ld t2 , 16(sp)  #ind

    la t4, buffer
    add t4, t4, t2 # a2 holds idx
    sb t5 , 0(t4)

    addi t1 , t1 , -1
    addi t2 , t2 , 1

    mv a0 , t0
    mv a1 , t1
    mv a2 , t2

    jal ra , paran

    ld a0 , 0(sp)   #open
    ld a1 , 8(sp)   #close
    ld a2 , 16(sp)  #ind
    ld ra , 24(sp)

exit_second_recur:
ld ra , 24(sp)
    addi sp , sp , 32
ret







